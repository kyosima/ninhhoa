import 'category_product_model.dart';

class CategoryArguments {
  int? id;
  String? title;
  List<Children>? children;
  CategoryArguments({this.id, this.title, this.children});
}
