import 'package:vincare/model/checkout/cart_model.dart';

class CartArguments {
  List<Data>? cartData;
  int? total;
  CartArguments({this.cartData, this.total});
}
