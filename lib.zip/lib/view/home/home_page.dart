import 'package:flutter/material.dart';
import 'package:flutter_image_slideshow/flutter_image_slideshow.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';
import 'package:vincare/widget/shimmer.dart';
import '../../controller/home/home_controller.dart';
import '../../model/product/category_arguments.dart';
import '../../unit.dart';
import '../../widget/custom_text.dart';

class HomePage extends StatelessWidget {
  final controller = Get.put(HomeController());
  HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final kWidth = MediaQuery.of(context).size.width;
    final kHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Obx(() {
          if (controller.isLoadingInfo.value) {
            return CText(
              text: 'Xin chào!',
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 16,
            );
          } else {
            return controller.userInfo.value == null
                ? CText(
                    text: 'Vin Care, Xin chào!',
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  )
                : Row(
                    children: [
                      CText(
                        text: 'Xin chào, ',
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                      CText(
                        text: '${controller.userInfo.value?.fullname}',
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                      ),
                    ],
                  );
          }
        }),
        actions: [
          Obx(
            () => Stack(
              alignment: Alignment.topRight,
              children: [
                Center(
                  child: IconButton(
                      onPressed: () {
                        if (controller.userInfo.value == null) {
                          Get.toNamed('/login');
                          Get.snackbar('Thông báo',
                              'Vui lòng đăng nhập để xem giỏ hàng');
                        } else {
                          Get.toNamed('/cart');
                        }
                      },
                      icon: const Icon(
                        Icons.shopping_cart_rounded,
                        size: 30,
                      )),
                ),
                controller.userInfo.value == null
                    ? Container()
                    : Container(
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(100),
                        ),
                        child: Center(child: Obx(() {
                          if (controller.isLoadingCart.value) {
                            return const SizedBox(
                              height: 10,
                              width: 10,
                              child: CircularProgressIndicator(
                                strokeWidth: 1,
                                color: Colors.white,
                              ),
                            );
                          } else {
                            return CText(
                              text: '${controller.cart.value!.length}',
                              fontSize: 11,
                              color: Colors.white,
                            );
                          }
                        })),
                      )
              ],
            ),
          ),
          const SizedBox(
            width: 5,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(kWidth * 0.05),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Obx(() {
                if (controller.isLoadingBanner.value) {
                  return Shimmer.fromColors(
                      child: ShimmerBox(height: kHeight * 0.2, width: kWidth),
                      baseColor: baseColor,
                      highlightColor: highlightColor);
                } else {
                  return ImageSlideshow(
                    width: double.infinity,
                    height: kHeight * 0.2,
                    initialPage: 0,
                    indicatorColor: pColor,
                    indicatorBackgroundColor: Colors.grey,
                    autoPlayInterval: 7000,
                    isLoop: true,
                    children: [
                      for (var i = 0;
                          i < controller.banner.value!.items!.length;
                          i++) ...[
                        ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.network(
                              '${controller.banner.value?.items![i].image}',
                              fit: BoxFit.cover,
                            )),
                      ]
                    ],
                  );
                }
              }),
              const SizedBox(
                height: 30,
              ),
              Row(
                children: [
                  const Icon(
                    Icons.camera_alt,
                    size: 30,
                    color: pColor,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  CText(
                    text: 'Danh mục sản phẩm',
                    fontSize: 19,
                    color: pColor,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Obx(() {
                if (controller.isLoadingCategoryProduct.value) {
                  return SizedBox(
                    height: kHeight * 0.21,
                    child: ListView.separated(
                      padding: EdgeInsets.zero,
                      itemCount: 5,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return Shimmer.fromColors(
                          baseColor: baseColor,
                          highlightColor: highlightColor,
                          child: Container(
                            width: kWidth * 0.32,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: ShimmerBox(
                                      height: kHeight * 0.1,
                                      width: double.infinity,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  ShimmerBox(
                                    height: 10,
                                    width: 60,
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  ShimmerBox(
                                    height: 10,
                                    width: 80,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                  ;
                } else {
                  return SizedBox(
                    height: kHeight * 0.21,
                    child: ListView.separated(
                      padding: EdgeInsets.zero,
                      itemCount: controller.categoryProduct.value!.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Get.toNamed('/productCategory',
                                arguments: CategoryArguments(
                                    id: controller
                                        .categoryProduct.value![index].id,
                                    title: controller
                                        .categoryProduct.value![index].name,
                                    children: controller.categoryProduct
                                        .value![index].children));
                          },
                          child: Container(
                            width: kWidth * 0.32,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Column(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.network(
                                      '${controller.categoryProduct.value![index].avatar}',
                                      fit: BoxFit.cover,
                                      height: kHeight * 0.1,
                                      width: double.infinity,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  CText(
                                    text:
                                        '${controller.categoryProduct.value![index].name}',
                                    maxLine: 2,
                                    fontWeight: FontWeight.w500,
                                  )
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                }
              }),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  const Icon(
                    Icons.hotel_class,
                    size: 30,
                    color: pColor,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  CText(
                    text: 'Sản phẩm nổi bật',
                    fontSize: 19,
                    color: pColor,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Obx(() {
                if (controller.isLoadingFeaturedProduct.value) {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: 5,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return Shimmer.fromColors(
                          baseColor: baseColor,
                          highlightColor: highlightColor,
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: ShimmerBox(
                                            height: kHeight * 0.12,
                                            width: double.infinity,
                                          )),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 6,
                                  ),
                                  ShimmerBox(
                                    height: 15,
                                    width: double.infinity,
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                } else {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: controller.featuredProduct.value!.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Get.toNamed('/productDetail',
                                arguments: controller
                                    .featuredProduct.value![index].id);
                          },
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Image.network(
                                          '${controller.featuredProduct.value![index].featureImage}',
                                          fit: BoxFit.cover,
                                          height: kHeight * 0.12,
                                          width: double.infinity,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      CText(
                                        text:
                                            '${controller.featuredProduct.value![index].name}',
                                        fontWeight: FontWeight.w500,
                                        maxLine: 2,
                                        textOverflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      CText(
                                        text:
                                            NumberFormat.currency(locale: 'vi')
                                                .format(controller
                                                    .featuredProduct
                                                    .value![index]
                                                    .price),
                                        fontWeight: FontWeight.w700,
                                        color: controller
                                                    .featuredProduct
                                                    .value![index]
                                                    .pricePromotion ==
                                                null
                                            ? pColor
                                            : Colors.grey,
                                        textDecoration: controller
                                                    .featuredProduct
                                                    .value![index]
                                                    .pricePromotion ==
                                                null
                                            ? TextDecoration.none
                                            : TextDecoration.lineThrough,
                                        fontSize: controller
                                                    .featuredProduct
                                                    .value![index]
                                                    .pricePromotion ==
                                                null
                                            ? 17
                                            : 15,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      controller.featuredProduct.value![index]
                                                  .pricePromotion ==
                                              null
                                          ? Container()
                                          : CText(
                                              text: NumberFormat.currency(
                                                      locale: 'vi')
                                                  .format(controller
                                                      .featuredProduct
                                                      .value![index]
                                                      .pricePromotion),
                                              fontWeight: FontWeight.w700,
                                              color: pColor,
                                            ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 6,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CText(
                                        text: 'Lượt xem: ',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      ),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      CText(
                                        text:
                                            '${controller.featuredProduct.value![index].viewed}',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                }
              }),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  const Icon(
                    Icons.fiber_new,
                    size: 30,
                    color: pColor,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  CText(
                    text: 'Sản phẩm mới',
                    fontSize: 19,
                    color: pColor,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Obx(() {
                if (controller.isLoadingNewProduct.value) {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: 5,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return Shimmer.fromColors(
                          baseColor: baseColor,
                          highlightColor: highlightColor,
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: ShimmerBox(
                                            height: kHeight * 0.12,
                                            width: double.infinity,
                                          )),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 6,
                                  ),
                                  ShimmerBox(
                                    height: 15,
                                    width: double.infinity,
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                } else {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: controller.newProduct.value!.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Get.toNamed('/productDetail',
                                arguments:
                                    controller.newProduct.value![index].id);
                          },
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Image.network(
                                          '${controller.newProduct.value![index].featureImage}',
                                          fit: BoxFit.cover,
                                          height: kHeight * 0.12,
                                          width: double.infinity,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      CText(
                                        text:
                                            '${controller.newProduct.value![index].name}',
                                        fontWeight: FontWeight.w500,
                                        maxLine: 2,
                                        textOverflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      CText(
                                        text:
                                            NumberFormat.currency(locale: 'vi')
                                                .format(controller.newProduct
                                                    .value![index].price),
                                        fontWeight: FontWeight.w700,
                                        maxLine: 1,
                                        textOverflow: TextOverflow.ellipsis,
                                        fontSize: controller
                                                    .newProduct
                                                    .value![index]
                                                    .pricePromotion ==
                                                null
                                            ? 17
                                            : 15,
                                        color: controller
                                                    .newProduct
                                                    .value![index]
                                                    .pricePromotion ==
                                                null
                                            ? pColor
                                            : Colors.grey,
                                        textDecoration: controller
                                                    .newProduct
                                                    .value![index]
                                                    .pricePromotion ==
                                                null
                                            ? TextDecoration.none
                                            : TextDecoration.lineThrough,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      controller.newProduct.value![index]
                                                  .pricePromotion ==
                                              null
                                          ? Container()
                                          : CText(
                                              text: NumberFormat.currency(
                                                      locale: 'vi')
                                                  .format(controller
                                                      .newProduct
                                                      .value![index]
                                                      .pricePromotion),
                                              fontWeight: FontWeight.w700,
                                              color: pColor,
                                              maxLine: 1,
                                              textOverflow:
                                                  TextOverflow.ellipsis,
                                            ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CText(
                                        text: 'Lượt xem: ',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      ),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      CText(
                                        text:
                                            '${controller.newProduct.value![index].viewed}',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                }
              }),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  const Icon(
                    Icons.star,
                    size: 30,
                    color: pColor,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  CText(
                    text: 'Mỹ Phẩm',
                    fontSize: 19,
                    color: pColor,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Obx(() {
                if (controller.isLoadingMypham.value) {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: 5,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return Shimmer.fromColors(
                          baseColor: baseColor,
                          highlightColor: highlightColor,
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: ShimmerBox(
                                            height: kHeight * 0.12,
                                            width: double.infinity,
                                          )),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 6,
                                  ),
                                  ShimmerBox(
                                    height: 15,
                                    width: double.infinity,
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                } else {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: controller.mypham.value!.products!.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Get.toNamed('/productDetail',
                                arguments: controller
                                    .mypham.value?.products![index].id);
                          },
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Image.network(
                                          '${controller.mypham.value?.products![index].featureImage}',
                                          fit: BoxFit.cover,
                                          height: kHeight * 0.12,
                                          width: double.infinity,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      CText(
                                        text:
                                            '${controller.mypham.value?.products![index].name}',
                                        fontWeight: FontWeight.w500,
                                        maxLine: 2,
                                        textOverflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      CText(
                                        text:
                                            NumberFormat.currency(locale: 'vi')
                                                .format(controller.mypham.value
                                                    ?.products![index].price),
                                        fontWeight: FontWeight.w700,
                                        maxLine: 1,
                                        textOverflow: TextOverflow.ellipsis,
                                        fontSize: controller
                                                    .mypham
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? 17
                                            : 15,
                                        color: controller
                                                    .mypham
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? pColor
                                            : Colors.grey,
                                        textDecoration: controller
                                                    .mypham
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? TextDecoration.none
                                            : TextDecoration.lineThrough,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      controller.mypham.value?.products![index]
                                                  .pricePromotion ==
                                              null
                                          ? Container()
                                          : CText(
                                              text: NumberFormat.currency(
                                                      locale: 'vi')
                                                  .format(controller
                                                      .mypham
                                                      .value
                                                      ?.products![index]
                                                      .pricePromotion),
                                              fontWeight: FontWeight.w700,
                                              color: pColor,
                                              maxLine: 1,
                                              textOverflow:
                                                  TextOverflow.ellipsis,
                                            ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CText(
                                        text: 'Lượt xem: ',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      ),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      CText(
                                        text:
                                            '${controller.mypham.value?.products![index].viewed}',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                }
              }),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  const Icon(
                    Icons.star,
                    size: 30,
                    color: pColor,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  CText(
                    text: 'Sữa',
                    fontSize: 19,
                    color: pColor,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Obx(() {
                if (controller.isLoadingSua.value) {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: 5,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return Shimmer.fromColors(
                          baseColor: baseColor,
                          highlightColor: highlightColor,
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: ShimmerBox(
                                            height: kHeight * 0.12,
                                            width: double.infinity,
                                          )),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 6,
                                  ),
                                  ShimmerBox(
                                    height: 15,
                                    width: double.infinity,
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                } else {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: controller.sua.value!.products!.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Get.toNamed('/productDetail',
                                arguments:
                                    controller.sua.value?.products![index].id);
                          },
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Image.network(
                                          '${controller.sua.value?.products![index].featureImage}',
                                          fit: BoxFit.cover,
                                          height: kHeight * 0.12,
                                          width: double.infinity,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      CText(
                                        text:
                                            '${controller.sua.value?.products![index].name}',
                                        fontWeight: FontWeight.w500,
                                        maxLine: 2,
                                        textOverflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      CText(
                                        text:
                                            NumberFormat.currency(locale: 'vi')
                                                .format(controller.sua.value
                                                    ?.products![index].price),
                                        fontWeight: FontWeight.w700,
                                        maxLine: 1,
                                        textOverflow: TextOverflow.ellipsis,
                                        fontSize: controller
                                                    .sua
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? 17
                                            : 15,
                                        color: controller
                                                    .sua
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? pColor
                                            : Colors.grey,
                                        textDecoration: controller
                                                    .sua
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? TextDecoration.none
                                            : TextDecoration.lineThrough,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      controller.sua.value?.products![index]
                                                  .pricePromotion ==
                                              null
                                          ? Container()
                                          : CText(
                                              text: NumberFormat.currency(
                                                      locale: 'vi')
                                                  .format(controller
                                                      .sua
                                                      .value
                                                      ?.products![index]
                                                      .pricePromotion),
                                              fontWeight: FontWeight.w700,
                                              color: pColor,
                                              maxLine: 1,
                                              textOverflow:
                                                  TextOverflow.ellipsis,
                                            ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CText(
                                        text: 'Lượt xem: ',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      ),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      CText(
                                        text:
                                            '${controller.sua.value?.products![index].viewed}',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                }
              }),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  const Icon(
                    Icons.star,
                    size: 30,
                    color: pColor,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  CText(
                    text: 'Đồ Uống Sức Khoẻ',
                    fontSize: 19,
                    color: pColor,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Obx(() {
                if (controller.isLoadingDouong.value) {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: 5,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return Shimmer.fromColors(
                          baseColor: baseColor,
                          highlightColor: highlightColor,
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: ShimmerBox(
                                            height: kHeight * 0.12,
                                            width: double.infinity,
                                          )),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 6,
                                  ),
                                  ShimmerBox(
                                    height: 15,
                                    width: double.infinity,
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                } else {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: controller.douong.value!.products!.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Get.toNamed('/productDetail',
                                arguments: controller
                                    .douong.value?.products![index].id);
                          },
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Image.network(
                                          '${controller.douong.value?.products![index].featureImage}',
                                          fit: BoxFit.cover,
                                          height: kHeight * 0.12,
                                          width: double.infinity,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      CText(
                                        text:
                                            '${controller.douong.value?.products![index].name}',
                                        fontWeight: FontWeight.w500,
                                        maxLine: 2,
                                        textOverflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      CText(
                                        text:
                                            NumberFormat.currency(locale: 'vi')
                                                .format(controller.douong.value
                                                    ?.products![index].price),
                                        fontWeight: FontWeight.w700,
                                        maxLine: 1,
                                        textOverflow: TextOverflow.ellipsis,
                                        fontSize: controller
                                                    .douong
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? 17
                                            : 15,
                                        color: controller
                                                    .douong
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? pColor
                                            : Colors.grey,
                                        textDecoration: controller
                                                    .douong
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? TextDecoration.none
                                            : TextDecoration.lineThrough,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      controller.douong.value?.products![index]
                                                  .pricePromotion ==
                                              null
                                          ? Container()
                                          : CText(
                                              text: NumberFormat.currency(
                                                      locale: 'vi')
                                                  .format(controller
                                                      .douong
                                                      .value
                                                      ?.products![index]
                                                      .pricePromotion),
                                              fontWeight: FontWeight.w700,
                                              color: pColor,
                                              maxLine: 1,
                                              textOverflow:
                                                  TextOverflow.ellipsis,
                                            ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CText(
                                        text: 'Lượt xem: ',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      ),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      CText(
                                        text:
                                            '${controller.douong.value?.products![index].viewed}',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                }
              }),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  const Icon(
                    Icons.star,
                    size: 30,
                    color: pColor,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  CText(
                    text: 'Dịch Vụ Dưỡng Sinh & Trị Liệu Da',
                    fontSize: 19,
                    color: pColor,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Obx(() {
                if (controller.isLoadingDichvu.value) {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: 5,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return Shimmer.fromColors(
                          baseColor: baseColor,
                          highlightColor: highlightColor,
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: ShimmerBox(
                                            height: kHeight * 0.12,
                                            width: double.infinity,
                                          )),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 6,
                                  ),
                                  ShimmerBox(
                                    height: 15,
                                    width: double.infinity,
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                } else {
                  return SizedBox(
                    height: kHeight * 0.29,
                    child: ListView.separated(
                      itemCount: controller.dichvu.value!.products!.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Get.toNamed('/productDetail',
                                arguments: controller
                                    .dichvu.value?.products![index].id);
                          },
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Image.network(
                                          '${controller.dichvu.value?.products![index].featureImage}',
                                          fit: BoxFit.cover,
                                          height: kHeight * 0.12,
                                          width: double.infinity,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      CText(
                                        text:
                                            '${controller.dichvu.value?.products![index].name}',
                                        fontWeight: FontWeight.w500,
                                        maxLine: 2,
                                        textOverflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      CText(
                                        text:
                                            NumberFormat.currency(locale: 'vi')
                                                .format(controller.dichvu.value
                                                    ?.products![index].price),
                                        fontWeight: FontWeight.w700,
                                        maxLine: 1,
                                        textOverflow: TextOverflow.ellipsis,
                                        fontSize: controller
                                                    .dichvu
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? 17
                                            : 15,
                                        color: controller
                                                    .dichvu
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? pColor
                                            : Colors.grey,
                                        textDecoration: controller
                                                    .dichvu
                                                    .value
                                                    ?.products![index]
                                                    .pricePromotion ==
                                                null
                                            ? TextDecoration.none
                                            : TextDecoration.lineThrough,
                                      ),
                                      const SizedBox(
                                        height: 3,
                                      ),
                                      controller.dichvu.value?.products![index]
                                                  .pricePromotion ==
                                              null
                                          ? Container()
                                          : CText(
                                              text: NumberFormat.currency(
                                                      locale: 'vi')
                                                  .format(controller
                                                      .dichvu
                                                      .value
                                                      ?.products![index]
                                                      .pricePromotion),
                                              fontWeight: FontWeight.w700,
                                              color: pColor,
                                              maxLine: 1,
                                              textOverflow:
                                                  TextOverflow.ellipsis,
                                            ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CText(
                                        text: 'Lượt xem: ',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      ),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      CText(
                                        text:
                                            '${controller.dichvu.value?.products![index].viewed}',
                                        color: Colors.grey,
                                        fontSize: 14,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                }
              }),
              const SizedBox(
                height: 30,
              ),
              Row(
                children: [
                  const Icon(
                    Icons.newspaper,
                    size: 30,
                    color: pColor,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  CText(
                    text: 'Tin tức',
                    fontSize: 19,
                    color: pColor,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              Obx(() {
                if (controller.isLoadingBlog.value) {
                  return SizedBox(
                    height: kHeight * 0.25,
                    child: ListView.separated(
                      itemCount: 5,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return Shimmer.fromColors(
                          baseColor: baseColor,
                          highlightColor: highlightColor,
                          child: Container(
                            width: kWidth * 0.37,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: ShimmerBox(
                                            height: kHeight * 0.12,
                                            width: double.infinity,
                                          )),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      ShimmerBox(
                                        height: 15,
                                        width: double.infinity,
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                } else {
                  return SizedBox(
                    height: kHeight * 0.25,
                    child: ListView.separated(
                      itemCount: controller.blogs.value!.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Get.toNamed('/blogDetail',
                                arguments: controller.blogs.value![index].id);
                          },
                          child: Container(
                            width: kWidth * 0.38,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.network(
                                      '${controller.blogs.value![index].featureImage}',
                                      fit: BoxFit.cover,
                                      height: kHeight * 0.12,
                                      width: double.infinity,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  CText(
                                    text: DateFormat('dd/MM/yyyy').format(
                                        DateTime.parse(controller
                                            .blogs.value![index].postedAt
                                            .toString())),
                                    fontWeight: FontWeight.w500,
                                    color: Colors.grey,
                                    fontSize: 13,
                                    textOverflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  CText(
                                    text:
                                        '${controller.blogs.value![index].title}',
                                    fontWeight: FontWeight.w500,
                                    maxLine: 2,
                                    textOverflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  );
                }
              })
            ],
          ),
        ),
      ),
    );
  }
}
