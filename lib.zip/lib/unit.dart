import 'package:flutter/material.dart';

const pColor = Color(0xff0f4c87);
const sColor = Colors.black;
const url = "https://server50.mevivu.com/banhang";
const tokenAccess = "ijCCtggxLEkG3Yg8hNKZJvMM4EA1Rw4VjVvyIOb7";
final baseColor = Colors.grey.withOpacity(0.5);
const highlightColor = Colors.white;
