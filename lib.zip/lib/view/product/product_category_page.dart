import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../controller/product/category_detail_controller.dart';
import '../../unit.dart';
import '../../widget/custom_text.dart';

class ProductCategory extends StatelessWidget {
  final controller = Get.put(CategoryDetailController());
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  ProductCategory({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final kWidth = MediaQuery.of(context).size.width;
    final kHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      key: _scaffoldKey,
      endDrawer: Drawer(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 30,
                ),
                CText(
                  text: 'Phân loại',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
                const SizedBox(
                  height: 30,
                ),
                controller.children == null
                    ? const Text('')
                    : ListView.separated(
                        itemCount: controller.children.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (BuildContext context, index) {
                          return InkWell(
                            onTap: () {
                              controller.getCategoryDetail(
                                  id: controller.children[index].id.toString());

                              Get.back();
                            },
                            child: Row(
                              children: [
                                Text(
                                  '${controller.children[index].name}',
                                  style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w400),
                                ),
                              ],
                            ),
                          );
                        },
                        separatorBuilder: (BuildContext context, int index) {
                          return Divider(
                            height: 40,
                            color: Colors.grey.withOpacity(0.3),
                          );
                        },
                      ),
                const SizedBox(
                  height: 30,
                ),
              ],
            ),
          ),
        ),
      ),
      appBar: AppBar(
        title: Obx(() {
          if (controller.isLoading.value) {
            return const Text('Danh mục sản phẩm');
          } else {
            return Text('${controller.categoryDetail.value?.name}');
          }
        }),
        actions: <Widget>[
          IconButton(
              onPressed: () {
                _scaffoldKey.currentState?.openEndDrawer();
              },
              icon: const Icon(Icons.filter_alt))
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(kWidth * 0.03),
          child: Column(
            children: [
              Obx(() {
                if (controller.isLoading.value) {
                  return SizedBox(
                      height: 0.7 * kHeight,
                      child: const Center(child: CircularProgressIndicator()));
                } else {
                  return GridView.count(
                    crossAxisCount: kWidth < 600 ? 2 : 3,
                    childAspectRatio:
                        kWidth / kHeight / (kWidth < 600 ? 0.74 : 0.9),
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: List.generate(
                        controller.categoryDetail.value!.products!.length,
                        (index) {
                      return InkWell(
                        onTap: () {
                          Get.toNamed('/productDetail',
                              arguments: controller
                                  .categoryDetail.value?.products![index].id);
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.blue.withOpacity(0.3)),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Center(
                                      child: ClipRRect(
                                        borderRadius: const BorderRadius.only(
                                            topRight: Radius.circular(10),
                                            topLeft: Radius.circular(10)),
                                        child: Image.network(
                                          '${controller.categoryDetail.value?.products![index].featureImage}',
                                          fit: BoxFit.cover,
                                          height: kHeight * 0.15,
                                          width: double.infinity,
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CText(
                                            text:
                                                '${controller.categoryDetail.value?.products![index].name}',
                                            fontWeight: FontWeight.w500,
                                            fontSize: kWidth < 600 ? 16 : 20,
                                            maxLine: 2,
                                            textOverflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          CText(
                                            text: NumberFormat.currency(
                                                    locale: 'vi')
                                                .format(controller
                                                    .categoryDetail
                                                    .value
                                                    ?.products![index]
                                                    .price),
                                            fontWeight: FontWeight.w600,
                                            fontSize: kWidth < 600
                                                ? (controller
                                                            .categoryDetail
                                                            .value
                                                            ?.products![index]
                                                            .pricePromotion !=
                                                        null
                                                    ? 15
                                                    : 18)
                                                : 20,
                                            color: controller
                                                        .categoryDetail
                                                        .value
                                                        ?.products![index]
                                                        .pricePromotion ==
                                                    null
                                                ? pColor
                                                : Colors.grey,
                                            textDecoration: controller
                                                        .categoryDetail
                                                        .value
                                                        ?.products![index]
                                                        .pricePromotion ==
                                                    null
                                                ? TextDecoration.none
                                                : TextDecoration.lineThrough,
                                          ),
                                          controller
                                                      .categoryDetail
                                                      .value
                                                      ?.products![index]
                                                      .pricePromotion ==
                                                  null
                                              ? Container()
                                              : Column(
                                                  children: [
                                                    const SizedBox(
                                                      height: 5,
                                                    ),
                                                    CText(
                                                      text: NumberFormat
                                                              .currency(
                                                                  locale: 'vi')
                                                          .format(controller
                                                              .categoryDetail
                                                              .value
                                                              ?.products![index]
                                                              .pricePromotion),
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontSize: kWidth < 600
                                                          ? 15
                                                          : 20,
                                                      color: pColor,
                                                    ),
                                                  ],
                                                ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CText(
                                        text: 'Lượt xem: ',
                                        color: Colors.grey,
                                        fontSize: 16,
                                      ),
                                      const SizedBox(
                                        width: 2,
                                      ),
                                      CText(
                                        text:
                                            '${controller.categoryDetail.value?.products![index].viewed}',
                                        color: Colors.grey,
                                        fontSize: 16,
                                      )
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                  );
                }
              })
            ],
          ),
        ),
      ),
    );
  }
}
